<?php
$con=mysqli_connect("localhost","root","","internshalatest");
//$con=mysqli_connect("sql300.epizy.com","epiz_27869536","Sj86TKDaiyiE","epiz_27869536_internshalatest");

?>