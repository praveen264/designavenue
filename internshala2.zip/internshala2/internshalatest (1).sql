-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 03, 2021 at 04:49 PM
-- Server version: 10.1.35-MariaDB
-- PHP Version: 7.2.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `internshalatest`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(30) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `username`, `password`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `bloodrequests`
--

CREATE TABLE `bloodrequests` (
  `id` int(40) NOT NULL,
  `bloodgroup` varchar(200) NOT NULL,
  `totalno` varchar(10) NOT NULL,
  `userid` varchar(200) NOT NULL,
  `name` varchar(200) NOT NULL,
  `hospital_id` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodrequests`
--

INSERT INTO `bloodrequests` (`id`, `bloodgroup`, `totalno`, `userid`, `name`, `hospital_id`) VALUES
(1, 'o+ve', '1', '1', 'Praveen Kumar Trivedi', '1'),
(2, 'A-ve', '2', '1', 'Praveen Kumar Trivedi', '1'),
(3, 'o-ve', '2', '1', 'sds', '1');

-- --------------------------------------------------------

--
-- Table structure for table `bloodsamples`
--

CREATE TABLE `bloodsamples` (
  `id` int(50) NOT NULL,
  `bloodgroup` varchar(50) NOT NULL,
  `hospital_id` int(50) NOT NULL,
  `totalno` int(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bloodsamples`
--

INSERT INTO `bloodsamples` (`id`, `bloodgroup`, `hospital_id`, `totalno`) VALUES
(1, 'O+ve', 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `hospitalregisteration`
--

CREATE TABLE `hospitalregisteration` (
  `id` int(30) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(400) NOT NULL,
  `contact` varchar(100) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hospitalregisteration`
--

INSERT INTO `hospitalregisteration` (`id`, `name`, `email`, `address`, `contact`, `password`) VALUES
(1, 'TMH', 'praveentrivedi619@gmail.com', '122222', 'zcz', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(30) NOT NULL,
  `product_type` varchar(200) NOT NULL,
  `price` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_type`, `price`) VALUES
(1, 'paneer butter masala', '250'),
(2, 'Veg Masala Dosa', '230'),
(3, 'Special Kathiyavadi', '200');

-- --------------------------------------------------------

--
-- Table structure for table `receiverregisteration`
--

CREATE TABLE `receiverregisteration` (
  `id` int(40) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `contact` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `receiverregisteration`
--

INSERT INTO `receiverregisteration` (`id`, `name`, `email`, `address`, `contact`, `password`) VALUES
(1, 'Praveen Kumar Trivedi', 'praveentrivedi619@gmail.com', 'UYUYGUG', 'zczdfsf', 'e10adc3949ba59abbe56e057f20f883e');

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `id` int(30) NOT NULL,
  `name` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(200) NOT NULL,
  `street_address` varchar(200) NOT NULL,
  `suburb` varchar(200) NOT NULL,
  `state` varchar(20) NOT NULL,
  `post_code` varchar(200) NOT NULL,
  `product_type` varchar(200) NOT NULL,
  `extra_upgrade` varchar(200) NOT NULL,
  `quantity` varchar(200) NOT NULL,
  `delivery_type` varchar(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`id`, `name`, `email`, `phone`, `street_address`, `suburb`, `state`, `post_code`, `product_type`, `extra_upgrade`, `quantity`, `delivery_type`) VALUES
(2, 'PRAVEEN KUMAR TRIVEDI', 'praveentrivedi619@gmail.com', '+916206665967', '264,NLO SITARAMDERA AGRICO JAMSHEDPUR-831009', 'jamshedpur', 'jHARKHAND', '831009', '1', '60', '2', '40');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(30) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `mname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `phone` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fname`, `email`, `mname`, `lname`, `phone`) VALUES
(1, 'PRAVEEN', 'praveentrivedi619@gmail.com', 'KUMAR', 'TRIVEDI', '+916206665967'),
(2, 'PRAVEEN', 'praveentrivedi619@gmail.com', 'KUMAR', 'TRIVEDI', '+916206665967'),
(3, 'PRAVEEN', 'praveentrivedi619@gmail.com', 'KUMAR', 'TRIVEDI', '+916206665967'),
(4, 'PRAVEEN', 'praveentrivedi619@gmail.com', 'KUMAR', 'TRIVEDI', '+916206665967'),
(5, 'PRAVEEN', 'praveentrivedi619@gmail.com', 'KUMAR', 'TRIVEDI', '+916206665967'),
(6, 'PRAVEEN', 'praveentrivedi619@gmail.com', 'KUMAR', 'TRIVEDI', '+916206665967'),
(7, 'PRAVEEN', 'praveentrivedi619@gmail.com', 'KUMAR', 'TRIVEDI', '+916206665967'),
(8, 'PRAVEEN', 'praveentrivedi619@gmail.com', 'KUMAR', 'TRIVEDI', '+916206665967'),
(9, 'PRAVEEN', 'praveentrivedi619@gmail.com', 'KUMAR', 'TRIVEDI', '+916206665967'),
(10, 'PRAVEEN', 'praveentrivedi619@gmail.com', 'KUMAR', 'TRIVEDI', '+916206665967'),
(11, 'PRAVEEN', 'praveentrivedi619@gmail.com', 'KUMAR', 'TRIVEDI', '+916206665967'),
(12, 'PRAVEEN', 'praveentrivedi619@gmail.com', 'KUMAR', 'TRIVEDI', '+916206665967');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodrequests`
--
ALTER TABLE `bloodrequests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `bloodsamples`
--
ALTER TABLE `bloodsamples`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hospitalregisteration`
--
ALTER TABLE `hospitalregisteration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `receiverregisteration`
--
ALTER TABLE `receiverregisteration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `bloodrequests`
--
ALTER TABLE `bloodrequests`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `bloodsamples`
--
ALTER TABLE `bloodsamples`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hospitalregisteration`
--
ALTER TABLE `hospitalregisteration`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `receiverregisteration`
--
ALTER TABLE `receiverregisteration`
  MODIFY `id` int(40) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
