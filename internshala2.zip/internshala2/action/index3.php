<?php
extract($_POST);
// echo $hospital_id;
// echo $bloodgroup;

include('../db.php');
$sql="insert into users(fname,email,phone,lname,mname)values('$fname','$email','$phone','$lname','$mname')";
$query=mysqli_query($con,$sql);
if($query)
{
  ?>
   <script type="text/javascript">
   alert("Record saved successfully");
   window.location.href="../index.php";
   </script>
   <?php
    
}

?>